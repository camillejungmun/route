<template>
    <div class="container container-field">
        <div class="card">
            <div class="card-body">
                <slot></slot> <!--填充内容放在solt中-->
            </div>
        </div>
    </div>
</template>

<script>

</script>

<style scoped>
div.container-field {
    margin-top: 20px;
}
</style>