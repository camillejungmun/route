package com.kob.backend.service.user.bot;

import java.util.Map;

public interface RemoveService {
    Map<String, String> remove(Map<String, String> data);
}
