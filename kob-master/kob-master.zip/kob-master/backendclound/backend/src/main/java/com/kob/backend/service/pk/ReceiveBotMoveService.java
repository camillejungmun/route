package com.kob.backend.service.pk;

public interface ReceiveBotMoveService {
    String receiveBotMove(Integer userId, Integer direction);
}
